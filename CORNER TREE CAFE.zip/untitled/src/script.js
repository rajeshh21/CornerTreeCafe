// Table Booking Form Script
document.getElementById("book-table").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form from submitting

    // Get input values
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const date = document.getElementById("date").value;
    const time = document.getElementById("time").value;
    const guests = document.getElementById("guests").value;

    // Basic validation (you can extend this as needed)
    if (name === "" || email === "" || date === "" || time === "" || guests === "") {
        alert("Please fill all the fields.");
        return;
    }

    // Display confirmation
    alert(`Table reserved successfully!\nName: ${name}\nEmail: ${email}\nDate: ${date}\nTime: ${time}\nGuests: ${guests}`);
    
    // Clear the form fields after submission
    document.getElementById("book-table").reset();
});

// Login Form Script
document.getElementById("login").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form from submitting

    // Get input values
    const loginEmail = document.getElementById("login-email").value;
    const loginPassword = document.getElementById("login-password").value;

    // Basic validation
    if (loginEmail === "" || loginPassword === "") {
        alert("Please enter your email and password.");
        return;
    }

    // Display login success
    alert(`Welcome back, ${loginEmail}!`);

    // Clear the login fields after submission
    document.getElementById("login").reset();
});
